
<div class="thumb mvic-thumb" style="background-image: url();">
<img title="" alt="" src="" class="hiddenz" style="width: 140px; height: 210px;">
</div>