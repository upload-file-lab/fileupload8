jQuery(document).ready(function(){
    jQuery('.datepicker').datepicker(); 
});